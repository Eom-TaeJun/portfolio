import os
crash_dir = 'C:/Users/TJ/Documents/.Rprofile'
os.makedirs(crash_dir, exist_ok=True)
